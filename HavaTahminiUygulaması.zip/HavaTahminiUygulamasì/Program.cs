﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using HavaTahminiUygulamasi;
using HavaTahminiUygulaması;
using Newtonsoft.Json;

namespace HavaTahminiUygulamasi
{
    class Program
    {
        static async Task Main()
        {
            Console.WriteLine("Lütfen bir şehir seçin (istanbul/izmir/ankara): ");
            string sehir = Console.ReadLine().ToLower();

            WeatherData weatherData = await WeatherApiClient.GetWeatherData(sehir);

            if (weatherData != null)
            {
                Console.WriteLine($"Hava Durumu Bilgileri - {sehir.ToUpper()}");
                Console.WriteLine($"Bugün: {weatherData.Temperature}");
                Console.WriteLine("Sonraki 3 Gün:");

                foreach (var forecast in weatherData.Forecast)
                {
                    Console.WriteLine($"{forecast.day}: {forecast.temperature}");
                }
            }
            else
            {
                Console.WriteLine("Hava durumu bilgileri alınamadı.");
            }
        }
    }
}

   