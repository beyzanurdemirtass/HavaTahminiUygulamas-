﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HavaTahminiUygulaması
{
    internal class Forecast
    {
        public string day { get; set; }
        public string temperature { get; set; }
    }
}
