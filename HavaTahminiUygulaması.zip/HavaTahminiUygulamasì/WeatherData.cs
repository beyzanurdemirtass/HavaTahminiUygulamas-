﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HavaTahminiUygulaması
{
    internal class WeatherData
    {
        public string Temperature { get; set; }
        public Forecast[] Forecast { get; set; }
    }
}
