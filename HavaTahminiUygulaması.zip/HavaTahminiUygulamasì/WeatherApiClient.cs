﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace HavaTahminiUygulaması
{
    internal class WeatherApiClient
    {
        private const string ApiBaseUrl = "https://goweather.herokuapp.com/weather/";

        public static async Task<WeatherData> GetWeatherData(string city)
        {
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    string apiUrl = $"{ApiBaseUrl}{city}";
                    string response = await client.GetStringAsync(apiUrl);
                    WeatherData weatherData = JsonConvert.DeserializeObject<WeatherData>(response);

                    return weatherData;
                }
                catch (HttpRequestException e)
                {
                    Console.WriteLine($"Hata oluştu: {e.Message}");
                    return null;
                }
            }
        }
    }
}

